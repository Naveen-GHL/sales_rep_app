import React, { useState, useEffect } from 'react';
import { useAuth } from './context/AuthContext';
import { AuthLayout } from './layouts/AuthLayout';
import { SalesLayout } from './layouts/SalesLayout';
import { AdminLayout } from './layouts/AdminLayout';

// Sales Core Pages
import { DashboardPage } from './pages/Dashboard/DashboardPage';
import { LeadsPage } from './pages/Leads/LeadsPage';
import { CustomersPage } from './pages/Customers/CustomersPage';
import { PipelinePage } from './pages/Pipeline/PipelinePage';
import { DealsPage } from './pages/Deals/DealsPage';
import { FollowupsPage } from './pages/Followups/FollowupsPage';
import { CallCenterPage } from './pages/CallCenter/CallCenterPage';
import { CallHistoryPage } from './pages/CallHistory/CallHistoryPage';
import { CallSettingsPage } from './pages/CallSettings/CallSettingsPage';
import { ReportsPage } from './pages/Reports/ReportsPage';
import { NotificationsPage } from './pages/Notifications/NotificationsPage';
import { NotInterestedPage } from './pages/NotInterested/NotInterestedPage';
import { JunkPage } from './pages/Junk/JunkPage';

const PlaceholderPage = ({ title }: { title: string }) => (
  <div style={{ padding: 24, textAlign: 'center' }}>
    <h2>{title}</h2>
    <p>This module is coming soon.</p>
  </div>
);

// Tenant Specific: Jamin
import { ProjectsPage } from './pages/Properties/ProjectsPage';
import { PlotsPage } from './pages/Plots/PlotsPage';
import { SiteVisitsPage } from './pages/SiteVisits/SiteVisitsPage';
import { BookingsPage } from './pages/Bookings/BookingsPage';

// Tenant Specific: GHL
import { InvestorsPage } from './pages/Investors/InvestorsPage';
import { ConsultationsPage } from './pages/Consultations/ConsultationsPage';
import { OpportunitiesPage } from './pages/InvestmentOpportunities/OpportunitiesPage';

// Company Admin
import { CompanyUsersPage } from './pages/Company/CompanyUsersPage';
import { CompanySettingsPage } from './pages/Company/CompanySettingsPage';
import { CompanyAuditPage } from './pages/Company/CompanyAuditPage';

// Super Admin Platform Pages
import { PlatformDashboardPage } from './pages/Admin/Dashboard/PlatformDashboardPage';
import { CompaniesPage } from './pages/Admin/Companies/CompaniesPage';
import { PlatformUsersPage } from './pages/Admin/Users/PlatformUsersPage';
import { PlatformRolesPage } from './pages/Admin/Roles/PlatformRolesPage';
import { PlatformFeaturesPage } from './pages/Admin/Features/PlatformFeaturesPage';
import { PlatformCallConfigPage } from './pages/Admin/CallConfig/PlatformCallConfigPage';
import { PlatformAuditPage } from './pages/Admin/Audit/PlatformAuditPage';

// Guards
import { ProtectedRoute } from './components/common/Guards';
import { Modal } from './components/common/Modal';
import { storageService } from './services/storageService';
import './App.css';

export const App: React.FC = () => {
  const { isAuthenticated, isSuperAdmin, tenant, user } = useAuth();
  const [currentRoute, setCurrentRoute] = useState<string>(() => {
    return sessionStorage.getItem('nexus_current_route') || 'dashboard';
  });

  // Seed initial mock data on clean install / empty session
  useEffect(() => {
    if (storageService.getUsers().length === 0) {
      storageService.loadMockDataFromSeparateFolder();
    }
  }, []);

  // Seed initial mock data on clean install / empty session
  useEffect(() => {
    if (storageService.getUsers().length === 0) {
      storageService.loadMockDataFromSeparateFolder();
    }
  }, []);

  // Quick Create Modal State
  const [quickCreateType, setQuickCreateType] = useState<
    'lead' | 'followup' | 'deal' | 'visit' | 'consultation' | null
  >(null);

  const [quickName, setQuickName] = useState('');
  const [quickPhone, setQuickPhone] = useState('+91 ');
  const [quickNotes, setQuickNotes] = useState('');
  const [scheduledDate, setScheduledDate] = useState(
    new Date(Date.now() + 86400000).toISOString().split('T')[0]
  );
  const [scheduledTime, setScheduledTime] = useState('11:00');

  // Deal-specific state
  const [dealCustomerMode, setDealCustomerMode] = useState<'existing' | 'new'>('existing');
  const [selectedCustomerId, setSelectedCustomerId] = useState('');
  const [newCustomerName, setNewCustomerName] = useState('');

  // Handle route change
  const navigate = (route: string) => {
    setCurrentRoute(route);
    sessionStorage.setItem('nexus_current_route', route);
  };

  const handleOpenQuickCreate = (type: 'lead' | 'followup' | 'deal' | 'visit' | 'consultation') => {
    setQuickCreateType(type);
    setQuickName('');
    setQuickPhone('+91 ');
    setQuickNotes('');
    setScheduledDate(new Date(Date.now() + 86400000).toISOString().split('T')[0]);
    setScheduledTime(storageService.getCallPreferences().defaultFollowupTime);
    // Reset deal-specific state; pre-select first available customer
    setDealCustomerMode('existing');
    setNewCustomerName('');
    const existingCustomers = storageService.getCustomers(tenant?.id);
    setSelectedCustomerId(existingCustomers[0]?.id || '');
  };

  const handleSaveQuickCreate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!quickName) return;

    if (quickCreateType === 'lead') {
      storageService.saveLead({
        id: `lead-${Date.now()}`,
        companyId: tenant?.id || 't-ghl-01',
        name: quickName,
        phone: quickPhone,
        email: '',
        location: 'Bengaluru',
        source: 'Quick Create',
        status: 'New',
        priority: 'Medium',
        assignedAgentId: user?.id || 'usr-exec',
        assignedAgentName: user?.name || 'Agent',
        createdAt: new Date().toISOString().split('T')[0],
        notes: quickNotes,
        customFields: {},
      });

    } else if (quickCreateType === 'followup') {
      const combinedDateTime = new Date(`${scheduledDate}T${scheduledTime}:00`).toISOString();
      storageService.saveFollowup({
        id: `flw-${Date.now()}`,
        companyId: tenant?.id || 't-ghl-01',
        contactId: `contact-${Date.now()}`,
        contactName: quickName,
        contactPhone: quickPhone,
        contactType: 'lead',
        scheduledAt: combinedDateTime,
        scheduledDate,
        scheduledTime,
        priority: 'High',
        status: 'Pending',
        notes: quickNotes,
        assignedAgentId: user?.id || 'usr-exec',
        assignedAgentName: user?.name || 'Agent',
      });

    } else if (quickCreateType === 'consultation') {
      // Task 1 — Schedule Consultation
      const combinedDateTime = new Date(`${scheduledDate}T${scheduledTime}:00`).toISOString();
      storageService.saveConsultation({
        id: `cons-${Date.now()}`,
        companyId: tenant?.id || 't-ghl-01',
        investorId: `investor-${Date.now()}`,
        investorName: quickName,
        investorPhone: quickPhone,
        scheduledAt: combinedDateTime,
        consultantId: user?.id || 'usr-exec',
        consultantName: user?.name || 'Agent',
        status: 'Scheduled',
        agenda: quickNotes || 'Initial consultation',
      });

    } else if (quickCreateType === 'visit') {
      // Task 2 — Schedule Site Visit
      const combinedDateTime = new Date(`${scheduledDate}T${scheduledTime}:00`).toISOString();
      storageService.saveSiteVisit({
        id: `visit-${Date.now()}`,
        companyId: tenant?.id || 't-jamin-02',
        customerId: `cust-${Date.now()}`,
        customerName: quickName,
        customerPhone: quickPhone,
        projectId: 'proj-01',
        projectName: 'Greenfield Meadows Phase 2',
        scheduledAt: combinedDateTime,
        assignedAgentId: user?.id || 'usr-exec',
        assignedAgentName: user?.name || 'Agent',
        status: 'Scheduled',
        outcomeNotes: quickNotes,
      });

    } else if (quickCreateType === 'deal') {
      // Task 4 — Deal linked to real customer
      let resolvedCustomerId: string;
      let resolvedCustomerName: string;

      if (dealCustomerMode === 'existing' && selectedCustomerId) {
        // Link to the chosen existing customer
        const existing = storageService.getCustomers(tenant?.id)
          .find(c => c.id === selectedCustomerId);
        resolvedCustomerId = existing?.id || selectedCustomerId;
        resolvedCustomerName = existing?.name || 'Customer';
      } else {
        // Create a real Customer record first so it shows in Customer 360
        if (!newCustomerName) return;
        resolvedCustomerId = `cust-${Date.now()}`;
        resolvedCustomerName = newCustomerName;
        storageService.saveCustomer({
          id: resolvedCustomerId,
          companyId: tenant?.id || 't-ghl-01',
          name: resolvedCustomerName,
          phone: quickPhone,
          email: '',
          status: 'Active',
          assignedAgentId: user?.id || 'usr-exec',
          assignedAgentName: user?.name || 'Agent',
          location: 'Bengaluru',
          lastContacted: new Date().toISOString().split('T')[0],
          openDealsCount: 1,
          totalValue: 5000000,
          createdAt: new Date().toISOString().split('T')[0],
          notes: '',
          customFields: {},
        });
      }

      storageService.saveDeal({
        id: `deal-${Date.now()}`,
        companyId: tenant?.id || 't-ghl-01',
        title: quickName,
        customerId: resolvedCustomerId,
        customerName: resolvedCustomerName,
        stage: 'new',
        value: 5000000,
        expectedCloseDate: '30 Days',
        assignedAgentId: user?.id || 'usr-exec',
        assignedAgentName: user?.name || 'Agent',
        notes: quickNotes,
        createdAt: new Date().toISOString().split('T')[0],
      });
    }

    setQuickCreateType(null);
  };

  // If unauthenticated
  if (!isAuthenticated) {
    return <AuthLayout />;
  }

  // Super Admin Console
  if (isSuperAdmin) {
    return (
      <AdminLayout currentRoute={currentRoute} onNavigate={navigate}>
        {currentRoute === 'admin-dashboard' || currentRoute === 'dashboard' ? (
          <PlatformDashboardPage onNavigate={navigate} />
        ) : currentRoute === 'admin-companies' ? (
          <CompaniesPage />
        ) : currentRoute === 'admin-users' ? (
          <PlatformUsersPage />
        ) : currentRoute === 'admin-roles' ? (
          <PlatformRolesPage />
        ) : currentRoute === 'admin-features' ? (
          <PlatformFeaturesPage />
        ) : currentRoute === 'admin-call-config' ? (
          <PlatformCallConfigPage />
        ) : currentRoute === 'admin-audit' ? (
          <PlatformAuditPage />
        ) : (
          <PlatformDashboardPage onNavigate={navigate} />
        )}
      </AdminLayout>
    );
  }

  // Company User Layout (GHL & Jamin)
  return (
    <SalesLayout
      currentRoute={currentRoute}
      onNavigate={navigate}
      onOpenQuickCreate={handleOpenQuickCreate}
    >
      {currentRoute === 'dashboard' ? (
        <DashboardPage onNavigate={navigate} onOpenQuickCreate={handleOpenQuickCreate} />
      ) : currentRoute === 'leads' ? (
        <LeadsPage />
      ) : currentRoute === 'customers' ? (
        <CustomersPage />
      ) : currentRoute === 'pipeline' ? (
        <PipelinePage onOpenQuickCreate={handleOpenQuickCreate} />
      ) : currentRoute === 'deals' ? (
        <DealsPage onNavigate={navigate} />
      ) : currentRoute === 'followups' ? (
        <FollowupsPage />
      ) : currentRoute === 'call-center' ? (
        <CallCenterPage />
      ) : currentRoute === 'call-history' ? (
        <CallHistoryPage />
      ) : currentRoute === 'call-settings' ? (
        <CallSettingsPage />
      ) : currentRoute === 'projects' ? (
        <ProjectsPage onNavigate={navigate} />
      ) : currentRoute === 'plots' ? (
        <PlotsPage />
      ) : currentRoute === 'site-visits' ? (
        <SiteVisitsPage />
      ) : currentRoute === 'bookings' ? (
        <BookingsPage />
      ) : currentRoute === 'investors' ? (
        <InvestorsPage />
      ) : currentRoute === 'consultations' ? (
        <ConsultationsPage />
      ) : currentRoute === 'opportunities' ? (
        <OpportunitiesPage />
      ) : currentRoute === 'not-interested' ? (
        <NotInterestedPage />
      ) : currentRoute === 'junk' ? (
        <JunkPage />
      ) : currentRoute === 'chat' ? (
        <PlaceholderPage title="Chat" />
      ) : currentRoute === 'smarty-ai' ? (
        <PlaceholderPage title="Smarty AI" />
      ) : currentRoute === 'profile' ? (
        <PlaceholderPage title="Profile" />
      ) : currentRoute === 'reports' ? (
        <ReportsPage />
      ) : currentRoute === 'notifications' ? (
        <NotificationsPage onNavigate={navigate} />
      ) : currentRoute === 'company-users' ? (
        <CompanyUsersPage />
      ) : currentRoute === 'company-settings' ? (
        <CompanySettingsPage />
      ) : currentRoute === 'company-audit' ? (
        <CompanyAuditPage />
      ) : (
        <DashboardPage onNavigate={navigate} onOpenQuickCreate={handleOpenQuickCreate} />
      )}

      {/* Global Quick Action Modal */}
      <Modal
        isOpen={!!quickCreateType}
        onClose={() => setQuickCreateType(null)}
        title={`Quick Create: ${quickCreateType?.toUpperCase()}`}
        subtitle={`Instant creation into ${tenant?.name}`}
      >
        <form onSubmit={handleSaveQuickCreate} className="app-quickcreate-form">

          {/* ── Deal Title (deals only) or Contact Name (everything else) ── */}
          <div className="form-group">
            <label className="form-label">
              {quickCreateType === 'deal' ? 'Deal Title *' : 'Contact Name *'}
            </label>
            <input
              type="text"
              className="form-input"
              required
              value={quickName}
              onChange={e => setQuickName(e.target.value)}
              placeholder={quickCreateType === 'deal' ? 'e.g. Commercial Plot Purchase' : 'e.g. Ramesh Chandra'}
            />
          </div>

          {/* ── Deal: existing vs. new customer picker (Task 4) ── */}
          {quickCreateType === 'deal' && (() => {
            const tenantCustomers = storageService.getCustomers(tenant?.id);
            const hasCustomers = tenantCustomers.length > 0;
            return (
              <div className="form-group">
                <label className="form-label">Link to Customer</label>

                {/* Segmented toggle — same style as Reports page period toggle */}
                <div className="app-segmented-toggle">
                  {(['existing', 'new'] as const).map(mode => (
                    <button
                      key={mode}
                      type="button"
                      className={`btn btn-sm app-segmented-btn ${dealCustomerMode === mode ? 'btn-primary' : 'btn-ghost'} ${mode === 'existing' && !hasCustomers ? 'disabled' : ''}`}
                      disabled={mode === 'existing' && !hasCustomers}
                      onClick={() => setDealCustomerMode(mode)}
                    >
                      {mode === 'existing' ? 'Existing customer' : 'New customer'}
                    </button>
                  ))}
                </div>

                {!hasCustomers && (
                  <p className="app-no-customers-msg">
                    No customers in this workspace yet — deal will create a new customer record.
                  </p>
                )}

                {dealCustomerMode === 'existing' && hasCustomers ? (
                  <select
                    className="form-select"
                    value={selectedCustomerId}
                    onChange={e => setSelectedCustomerId(e.target.value)}
                    required
                  >
                    {tenantCustomers.map(c => (
                      <option key={c.id} value={c.id}>
                        {c.name}{c.phone ? ` · ${c.phone}` : ''}
                      </option>
                    ))}
                  </select>
                ) : (
                  <div>
                    <label className="form-label app-new-customer-label">
                      New Customer Name * — a new Customer record will be created
                    </label>
                    <input
                      type="text"
                      className="form-input"
                      required
                      placeholder="Customer full name"
                      value={newCustomerName}
                      onChange={e => setNewCustomerName(e.target.value)}
                    />
                  </div>
                )}
              </div>
            );
          })()}

          {/* ── Phone (all types except deal-existing-customer) ── */}
          {!(quickCreateType === 'deal' && dealCustomerMode === 'existing') && (
            <div className="form-group">
              <label className="form-label">Phone Number</label>
              <input
                type="text"
                className="form-input"
                value={quickPhone}
                onChange={e => setQuickPhone(e.target.value)}
              />
            </div>
          )}

          {/* ── Scheduled Date + Time (followup, consultation, visit) ── */}
          {(quickCreateType === 'followup' || quickCreateType === 'consultation' || quickCreateType === 'visit') && (
            <div className="app-schedule-grid">
              <div className="form-group">
                <label className="form-label">Scheduled Date *</label>
                <input
                  type="date"
                  className="form-input"
                  required
                  value={scheduledDate}
                  onChange={e => setScheduledDate(e.target.value)}
                />
              </div>
              <div className="form-group">
                <label className="form-label">Scheduled Time *</label>
                <input
                  type="time"
                  className="form-input"
                  required
                  value={scheduledTime}
                  onChange={e => setScheduledTime(e.target.value)}
                />
              </div>
            </div>
          )}

          <div className="form-group">
            <label className="form-label">
              {quickCreateType === 'consultation' ? 'Consultation Agenda' : 'Quick Notes'}
            </label>
            <textarea
              className="form-textarea"
              rows={2}
              value={quickNotes}
              onChange={e => setQuickNotes(e.target.value)}
              placeholder={
                quickCreateType === 'consultation'
                  ? 'Topics to discuss, investor interest area...'
                  : quickCreateType === 'visit'
                  ? 'Special requirements, preferred plots...'
                  : 'Brief requirement summary...'
              }
            />
          </div>

          <div className="app-modal-actions">
            <button type="button" className="btn btn-secondary" onClick={() => setQuickCreateType(null)}>
              Cancel
            </button>
            <button type="submit" className="btn btn-primary">
              Save Entry
            </button>
          </div>
        </form>
      </Modal>
    </SalesLayout>
  );
};

export default App;
