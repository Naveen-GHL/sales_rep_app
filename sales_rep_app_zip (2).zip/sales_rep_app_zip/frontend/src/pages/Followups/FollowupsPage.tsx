import React, { useState, useEffect } from 'react';
import {
  CalendarCheck,
  Phone,
  CheckCircle,
  Clock,
  AlertTriangle,
  ArrowRight,
  FileText,
  Volume2,
  ChevronDown,
  ChevronUp,
  UserCheck,
  Building2,
} from 'lucide-react';
import { Followup, Lead, CallRecord } from '../../types';
import { useAuth } from '../../context/AuthContext';
import { useCall } from '../../context/CallContext';
import { storageService } from '../../services/storageService';
import { StatusChip } from '../../components/common/StatusChip';
import { Modal } from '../../components/common/Modal';
import { Drawer } from '../../components/common/Drawer';
import './FollowupsPage.css';

export const FollowupsPage: React.FC = () => {
  const { tenant, user } = useAuth();
  const { initiateCall } = useCall();

  const [followups, setFollowups] = useState<Followup[]>([]);
  const [activeTab, setActiveTab] = useState<'all' | 'due' | 'overdue' | 'completed'>('all');
  const [rescheduleItem, setRescheduleItem] = useState<Followup | null>(null);
  const [newDate, setNewDate] = useState('');

  // Profile Drawer state for GHL Sales Exec
  const [drawerFollowup, setDrawerFollowup] = useState<Followup | null>(null);
  const [expandedTranscripts, setExpandedTranscripts] = useState<Record<string, boolean>>({});

  const roleCode = user?.role?.code;
  const isExec = roleCode === 'sales_executive';
  const isGhlSalesExec = tenant?.slug === 'ghl' && isExec;

  const scopedFollowups = isExec
    ? followups.filter(f =>
        (f.assignedAgentId && f.assignedAgentId === user?.id) ||
        (f.assignedAgentName && f.assignedAgentName === user?.name)
      )
    : followups;

  const loadData = () => {
    if (tenant?.slug === 'ghl') {
      storageService.cleanupGhlPendingFollowups(tenant?.id);
    }
    setFollowups(storageService.getFollowups(tenant?.id) || []);
  };

  useEffect(() => {
    loadData();
    const handleUpdate = () => loadData();
    window.addEventListener('nexus_storage_updated', handleUpdate);
    return () => window.removeEventListener('nexus_storage_updated', handleUpdate);
  }, [tenant?.id]);

  const handleComplete = (f: Followup) => {
    storageService.saveFollowup({
      ...f,
      status: f.status === 'Completed' ? 'Pending' : 'Completed',
    });
  };

  const handleSaveReschedule = () => {
    if (rescheduleItem && newDate) {
      storageService.saveFollowup({
        ...rescheduleItem,
        scheduledAt: newDate,
        status: 'Pending',
      });
      setRescheduleItem(null);
      setNewDate('');
    }
  };

  // Safely deduplicate display rows for GHL Sales Exec (try/catch protected)
  let processedFollowups = scopedFollowups;
  if (isGhlSalesExec) {
    try {
      const seen = new Map<string, Followup>();
      const deduped: Followup[] = [];

      for (const f of scopedFollowups) {
        if (f.status !== 'Pending') {
          deduped.push(f);
          continue;
        }
        const phoneDigits = (f.contactPhone || '').replace(/\D/g, '').slice(-10);
        const key = (f.contactId && f.contactId !== 'contact-new')
          ? `id:${f.contactId}`
          : phoneDigits ? `phone:${phoneDigits}` : `raw:${f.id}`;

        if (!seen.has(key)) {
          seen.set(key, f);
          deduped.push(f);
        }
      }
      processedFollowups = deduped;
    } catch (err) {
      console.error('Error deduping followups list:', err);
      processedFollowups = scopedFollowups;
    }
  }

  const callsList = storageService.getCalls(tenant?.id) || [];

  const getCallCountForFollowup = (f: Followup): number => {
    if (!isGhlSalesExec) return 0;
    const fPhoneDigits = (f.contactPhone || '').replace(/\D/g, '').slice(-10);
    return callsList.filter(c => {
      if (f.contactId && f.contactId !== 'contact-new' && (c.leadId === f.contactId || c.contactId === f.contactId)) {
        return true;
      }
      const cPhoneDigits = (c.contactPhone || '').replace(/\D/g, '').slice(-10);
      return cPhoneDigits && fPhoneDigits && cPhoneDigits === fPhoneDigits;
    }).length;
  };

  const filteredFollowups = processedFollowups.filter(f => {
    if (activeTab === 'due') {
      return f.status === 'Pending' && (f.scheduledAt || '').toLowerCase().includes('today');
    }
    if (activeTab === 'overdue') {
      return f.status === 'Pending' && (f.scheduledAt || '').toLowerCase().includes('yesterday');
    }
    if (activeTab === 'completed') {
      return f.status === 'Completed';
    }
    return true;
  });

  // Contact profile drawer data lookups
  const selectedLead = drawerFollowup ? (
    (storageService.getLeads(tenant?.id) || []).find(l => {
      if (drawerFollowup.contactId && drawerFollowup.contactId !== 'contact-new' && l.id === drawerFollowup.contactId) {
        return true;
      }
      const lPhone = (l.phone || '').replace(/\D/g, '').slice(-10);
      const fPhone = (drawerFollowup.contactPhone || '').replace(/\D/g, '').slice(-10);
      return lPhone && fPhone && lPhone === fPhone;
    })
  ) : null;

  const selectedCalls = drawerFollowup ? (
    callsList.filter(c => {
      const isMatch = (drawerFollowup.contactId && drawerFollowup.contactId !== 'contact-new' && (c.leadId === drawerFollowup.contactId || c.contactId === drawerFollowup.contactId))
        || ((c.contactPhone || '').replace(/\D/g, '').slice(-10) === (drawerFollowup.contactPhone || '').replace(/\D/g, '').slice(-10) && (drawerFollowup.contactPhone || '').replace(/\D/g, '').slice(-10).length > 0);

      if (!isMatch) return false;

      // FIX 2: Show ONLY calls with 'Follow-up Required' or 'Call Back' disposition
      return c.disposition === 'Follow-up Required' || c.disposition === 'Call Back';
    })
  ) : [];

  const toggleTranscript = (callId: string) => {
    setExpandedTranscripts(prev => ({ ...prev, [callId]: !prev[callId] }));
  };

  const formatDuration = (sec: number) => {
    if (!sec || sec <= 0) return '0s';
    const m = Math.floor(sec / 60);
    const s = sec % 60;
    return m > 0 ? `${m}m ${s}s` : `${s}s`;
  };

  return (
    <div className="followups-page-container">
      {/* Header */}
      <div className="page-header">
        <div>
          <h1 className="page-title">
            <CalendarCheck size={24} color="var(--primary-600)" /> Follow-ups & Reminders
          </h1>
          <p className="page-subtitle">
            Keep commitments, maintain pipeline velocity, and log outcomes seamlessly.
          </p>
        </div>
      </div>

      {/* Tabs */}
      <div className="followups-tabs-container">
        {[
          { id: 'all', label: `All Tasks (${processedFollowups.length})` },
          { id: 'due', label: `Due Today (${processedFollowups.filter(f => f.status === 'Pending' && (f.scheduledAt || '').toLowerCase().includes('today')).length})` },
          { id: 'overdue', label: `Overdue (${processedFollowups.filter(f => f.status === 'Pending' && (f.scheduledAt || '').toLowerCase().includes('yesterday')).length})`, danger: true },
          { id: 'completed', label: `Completed (${processedFollowups.filter(f => f.status === 'Completed').length})` },
        ].map(tab => (
          <button
            key={tab.id}
            className={`btn btn-sm ${activeTab === tab.id ? 'btn-primary' : 'btn-secondary'} ${tab.danger && activeTab === tab.id ? 'followups-tab-danger-active' : tab.danger ? 'followups-tab-danger-inactive' : ''}`}
            onClick={() => setActiveTab(tab.id as any)}
          >
            {tab.danger && <AlertTriangle size={13} color={activeTab === tab.id ? '#ffffff' : '#dc2626'} />}
            {tab.label}
          </button>
        ))}
      </div>

      {/* Follow-ups List Cards */}
      <div className="followups-list">
        {filteredFollowups.length === 0 ? (
          <div className="card text-center followups-empty-card">
            No tasks in this category. You're all caught up!
          </div>
        ) : (
          filteredFollowups.map(f => {
            const isOverdue = f.status === 'Pending' && (f.scheduledAt || '').toLowerCase().includes('yesterday');
            const callCount = getCallCountForFollowup(f);

            return (
              <div
                key={f.id}
                className={`card card-hover followup-item-card ${isOverdue ? 'overdue' : ''} ${f.status === 'Completed' ? 'completed' : ''}`}
                onClick={isGhlSalesExec ? () => setDrawerFollowup(f) : undefined}
                style={isGhlSalesExec ? { cursor: 'pointer' } : undefined}
              >
                <div className="followup-item-left">
                  <button
                    className="btn btn-ghost btn-icon btn-sm followup-check-btn"
                    title={f.status === 'Completed' ? 'Completed' : 'Mark Completed'}
                    onClick={(e) => {
                      e.stopPropagation();
                      handleComplete(f);
                    }}
                  >
                    {f.status === 'Completed' ? (
                      <CheckCircle size={16} color="#059669" />
                    ) : (
                      <span className="followup-check-empty" />
                    )}
                  </button>

                  <div>
                    <div className="followup-contact-header" style={{ display: 'flex', alignItems: 'center', gap: 8, flexWrap: 'wrap' }}>
                      <span
                        className={`followup-contact-name ${f.status === 'Completed' ? 'completed' : ''}`}
                        style={isGhlSalesExec ? { color: 'var(--primary-600)', fontWeight: 700 } : undefined}
                      >
                        {f.contactName}
                      </span>

                      <StatusChip status={f.priority} size="sm" />

                      {isGhlSalesExec && (
                        <span
                          style={{
                            backgroundColor: '#f1f5f9',
                            color: '#475569',
                            fontSize: 11,
                            fontWeight: 600,
                            padding: '2px 8px',
                            borderRadius: 12,
                            display: 'inline-flex',
                            alignItems: 'center',
                            gap: 4,
                          }}
                        >
                          📞 {callCount} {callCount === 1 ? 'call' : 'calls'}
                        </span>
                      )}

                      <span className="followup-contact-phone">
                        Phone: {f.contactPhone}
                      </span>
                    </div>
                    <p className="followup-notes">
                      {f.notes}
                    </p>
                    <div className="followup-meta-row">
                      <span className={`followup-schedule-time ${isOverdue ? 'overdue' : ''}`}>
                        ⏰ {f.scheduledAt}
                      </span>
                      <span className="followup-assignee">• Assignee: {f.assignedAgentName}</span>
                    </div>
                  </div>
                </div>

                <div className="followup-actions-right">
                  <button
                    className="btn btn-secondary btn-sm"
                    onClick={(e) => {
                      e.stopPropagation();
                      setRescheduleItem(f);
                    }}
                  >
                    Reschedule
                  </button>
                  <button
                    className="btn btn-call btn-sm"
                    onClick={(e) => {
                      e.stopPropagation();
                      initiateCall(f.contactName, f.contactPhone, f.contactType as any, f.contactId);
                    }}
                  >
                    <Phone size={13} /> Call
                  </button>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Reschedule Modal */}
      <Modal
        isOpen={!!rescheduleItem}
        onClose={() => setRescheduleItem(null)}
        title="Reschedule Follow-up"
        subtitle={`Adjust scheduled reminder date for ${rescheduleItem?.contactName}`}
        footer={
          <>
            <button className="btn btn-secondary" onClick={() => setRescheduleItem(null)}>
              Cancel
            </button>
            <button className="btn btn-primary" onClick={handleSaveReschedule}>
              Save New Slot
            </button>
          </>
        }
      >
        <div className="form-group">
          <label className="form-label">New Date & Time</label>
          <input
            type="text"
            className="form-input"
            value={newDate}
            onChange={e => setNewDate(e.target.value)}
            placeholder="e.g. Next Monday, 10:00 AM"
          />
        </div>
      </Modal>

      {/* Contact Profile Drawer (GHL Sales Exec only) */}
      {isGhlSalesExec && (
        <Drawer
          isOpen={!!drawerFollowup}
          onClose={() => setDrawerFollowup(null)}
          title={drawerFollowup?.contactName || 'Contact Profile'}
          subtitle={`Phone: ${drawerFollowup?.contactPhone || '—'} • ${tenant?.name}`}
          width={600}
        >
          {drawerFollowup && (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
              {/* Header Stat Badge */}
              <div
                style={{
                  backgroundColor: 'var(--bg-surface-hover)',
                  border: '1px solid var(--border-base)',
                  borderRadius: 'var(--radius-lg)',
                  padding: '14px 18px',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'space-between',
                }}
              >
                <div>
                  <div style={{ fontSize: 12, color: 'var(--text-secondary)', textTransform: 'uppercase', fontWeight: 700 }}>
                    Total Activity Summary
                  </div>
                  <div style={{ fontSize: 16, fontWeight: 800, marginTop: 2, color: 'var(--primary-600)' }}>
                    {selectedCalls.length} {selectedCalls.length === 1 ? 'Call Recorded' : 'Calls Recorded'} • 1 Active Follow-up
                  </div>
                </div>
                <button
                  className="btn btn-call btn-sm"
                  onClick={() => {
                    initiateCall(
                      drawerFollowup.contactName,
                      drawerFollowup.contactPhone,
                      drawerFollowup.contactType as any,
                      drawerFollowup.contactId
                    );
                  }}
                >
                  <Phone size={13} /> Call Now
                </button>
              </div>

              {/* Section A: Lead / Investor Details */}
              <div className="card">
                <h4 style={{ fontSize: 15, fontWeight: 700, marginBottom: 12, display: 'flex', alignItems: 'center', gap: 8 }}>
                  <Building2 size={16} color="var(--primary-600)" /> Lead / Investor Details
                </h4>

                {selectedLead ? (
                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, fontSize: 13 }}>
                    {selectedLead.name && (
                      <div>
                        <span style={{ color: 'var(--text-secondary)', fontSize: 11, fontWeight: 600 }}>FULL NAME</span>
                        <div style={{ fontWeight: 600 }}>{selectedLead.name}</div>
                      </div>
                    )}
                    {selectedLead.phone && (
                      <div>
                        <span style={{ color: 'var(--text-secondary)', fontSize: 11, fontWeight: 600 }}>PHONE NUMBER</span>
                        <div style={{ fontWeight: 600 }}>{selectedLead.phone}</div>
                      </div>
                    )}
                    {selectedLead.email && (
                      <div>
                        <span style={{ color: 'var(--text-secondary)', fontSize: 11, fontWeight: 600 }}>EMAIL</span>
                        <div style={{ fontWeight: 600 }}>{selectedLead.email}</div>
                      </div>
                    )}
                    {selectedLead.location && (
                      <div>
                        <span style={{ color: 'var(--text-secondary)', fontSize: 11, fontWeight: 600 }}>LOCATION</span>
                        <div style={{ fontWeight: 600 }}>{selectedLead.location}</div>
                      </div>
                    )}
                    {selectedLead.source && (
                      <div>
                        <span style={{ color: 'var(--text-secondary)', fontSize: 11, fontWeight: 600 }}>SOURCE</span>
                        <div style={{ fontWeight: 600 }}>{selectedLead.source}</div>
                      </div>
                    )}
                    {selectedLead.status && (
                      <div>
                        <span style={{ color: 'var(--text-secondary)', fontSize: 11, fontWeight: 600 }}>STATUS</span>
                        <div><StatusChip status={selectedLead.status} size="sm" /></div>
                      </div>
                    )}
                    {selectedLead.priority && (
                      <div>
                        <span style={{ color: 'var(--text-secondary)', fontSize: 11, fontWeight: 600 }}>PRIORITY</span>
                        <div><StatusChip status={selectedLead.priority} size="sm" /></div>
                      </div>
                    )}
                    {selectedLead.createdAt && (
                      <div>
                        <span style={{ color: 'var(--text-secondary)', fontSize: 11, fontWeight: 600 }}>INTAKE DATE</span>
                        <div style={{ fontWeight: 600 }}>{selectedLead.createdAt}</div>
                      </div>
                    )}
                    {selectedLead.preferredLanguage && (
                      <div>
                        <span style={{ color: 'var(--text-secondary)', fontSize: 11, fontWeight: 600 }}>PREFERRED LANGUAGE</span>
                        <div style={{ fontWeight: 600 }}>{selectedLead.preferredLanguage}</div>
                      </div>
                    )}
                    {selectedLead.preferredContactTime && (
                      <div>
                        <span style={{ color: 'var(--text-secondary)', fontSize: 11, fontWeight: 600 }}>PREFERRED CONTACT TIME</span>
                        <div style={{ fontWeight: 600 }}>{selectedLead.preferredContactTime}</div>
                      </div>
                    )}
                    {selectedLead.notes && (
                      <div style={{ gridColumn: 'span 2' }}>
                        <span style={{ color: 'var(--text-secondary)', fontSize: 11, fontWeight: 600 }}>NOTES & REQUIREMENTS</span>
                        <div style={{ backgroundColor: 'var(--bg-surface-hover)', padding: '8px 12px', borderRadius: 6, marginTop: 4 }}>
                          {selectedLead.notes}
                        </div>
                      </div>
                    )}
                    {selectedLead.customFields && Object.keys(selectedLead.customFields).length > 0 && (
                      <div style={{ gridColumn: 'span 2', marginTop: 8 }}>
                        <span style={{ color: 'var(--text-secondary)', fontSize: 11, fontWeight: 600 }}>CUSTOM ATTRIBUTES</span>
                        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8, marginTop: 4 }}>
                          {Object.entries(selectedLead.customFields).map(([k, v]) => (
                            <div key={k} style={{ backgroundColor: 'var(--bg-surface-hover)', padding: '6px 10px', borderRadius: 6 }}>
                              <span style={{ fontSize: 10, color: 'var(--text-secondary)', textTransform: 'uppercase' }}>{k}</span>
                              <div style={{ fontWeight: 600 }}>{String(v)}</div>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                ) : (
                  <div style={{ padding: '16px', backgroundColor: 'var(--bg-surface-hover)', borderRadius: 8, color: 'var(--text-muted)', fontSize: 13, textAlign: 'center' }}>
                    Lead details unavailable
                  </div>
                )}
              </div>

              {/* Section B & C: Call Log & Audio / Transcription */}
              <div className="card">
                <h4 style={{ fontSize: 15, fontWeight: 700, marginBottom: 12, display: 'flex', alignItems: 'center', gap: 8 }}>
                  <Phone size={16} color="var(--primary-600)" /> Call Log & Recordings
                </h4>

                {selectedCalls.length === 0 ? (
                  <div style={{ padding: '16px', backgroundColor: 'var(--bg-surface-hover)', borderRadius: 8, color: 'var(--text-muted)', fontSize: 13, textAlign: 'center' }}>
                    No previous call logs recorded for this contact.
                  </div>
                ) : (
                  <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
                    {selectedCalls.map(c => {
                      const isExpanded = !!expandedTranscripts[c.id];
                      return (
                        <div
                          key={c.id}
                          style={{
                            border: '1px solid var(--border-base)',
                            borderRadius: 'var(--radius-md)',
                            padding: '12px 14px',
                            backgroundColor: 'var(--bg-surface)',
                          }}
                        >
                          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 8, flexWrap: 'wrap' }}>
                            <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                              <span
                                style={{
                                  fontSize: 11,
                                  fontWeight: 700,
                                  padding: '2px 8px',
                                  borderRadius: 10,
                                  backgroundColor: c.direction === 'inbound' ? '#dcfce7' : '#e0f2fe',
                                  color: c.direction === 'inbound' ? '#15803d' : '#0369a1',
                                }}
                              >
                                {c.direction === 'inbound' ? '↙ Inbound' : '↗ Outbound'}
                              </span>
                              <span style={{ fontSize: 12, fontWeight: 600 }}>{c.timestamp}</span>
                              <span style={{ fontSize: 12, color: 'var(--text-secondary)' }}>• {formatDuration(c.duration)}</span>
                            </div>
                            <StatusChip status={c.disposition} size="sm" />
                          </div>

                          {c.notes && (
                            <div style={{ fontSize: 12, color: 'var(--text-secondary)', marginTop: 6 }}>
                              <strong>Notes:</strong> {c.notes}
                            </div>
                          )}

                          {/* Inline Audio Player */}
                          {c.recordingUrl && (
                            <div style={{ marginTop: 10 }}>
                              <div style={{ fontSize: 11, color: 'var(--text-secondary)', fontWeight: 600, display: 'flex', alignItems: 'center', gap: 4, marginBottom: 4 }}>
                                <Volume2 size={12} /> Call Recording Audio
                              </div>
                              <audio controls src={c.recordingUrl} style={{ width: '100%', height: 36 }} />
                            </div>
                          )}

                          {/* Collapsible Transcription */}
                          {c.transcription && (
                            <div style={{ marginTop: 8 }}>
                              <button
                                type="button"
                                className="btn btn-ghost btn-sm"
                                style={{ padding: '2px 6px', fontSize: 11, gap: 4, color: 'var(--primary-600)' }}
                                onClick={() => toggleTranscript(c.id)}
                              >
                                <FileText size={12} />
                                {isExpanded ? 'Hide Transcription' : 'View Automated Transcription'}
                                {isExpanded ? <ChevronUp size={12} /> : <ChevronDown size={12} />}
                              </button>

                              {isExpanded && (
                                <div
                                  style={{
                                    marginTop: 6,
                                    padding: '10px 12px',
                                    backgroundColor: 'var(--bg-surface-hover)',
                                    borderRadius: 6,
                                    fontSize: 12,
                                    lineHeight: 1.5,
                                    color: 'var(--text-primary)',
                                    borderLeft: '3px solid var(--primary-600)',
                                  }}
                                >
                                  {c.transcription}
                                </div>
                              )}
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            </div>
          )}
        </Drawer>
      )}
    </div>
  );
};